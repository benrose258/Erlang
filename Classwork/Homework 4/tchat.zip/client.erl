% Ben Rose
% I pledge my honor that I have abided by the Stevens Honor System.
% 11/16/2020, due 11/29/2020

% NOTE NOTE NOTE NOTE NOTE NOTE NOTE NOTE NOTE NOTE NOTE NOTE NOTE
% YOU MUST FOLLOW ALL OF THE SPECIFICATIONS STARTING ON PAGE 11 EXTREMELY CLOSELY
% SO YOU DON'T FAIL THE TEST CASES!!!
% END NOTE END NOTE END NOTE END NOTE END NOTE END NOTE END NOTE

-module(client).

-author("Ben Rose").

-export([main/1, initial_state/2]).

-include_lib("./defs.hrl").

-spec main(_InitialState) -> _.
-spec listen(_State) -> _.
-spec initial_state(_Nick, _GuiName) -> _InitialClientState.
-spec loop(_State, _Request, _Ref) -> _.
-spec do_join(_State, _Ref, _ChatName) -> _.
-spec do_leave(_State, _Ref, _ChatName) -> _.
-spec do_new_nick(_State, _Ref, _NewNick) -> _.
-spec do_new_incoming_msg(_State, _Ref, _SenderNick, _ChatName, _Message) -> _.

%% Receive messages from GUI and handle them accordingly
%% All handling can be done in loop(...)
main(InitialState) ->
    %% The client tells the server it is connecting with its initial nickname.
    %% This nickname is guaranteed unique system-wide as long as you do not assign a client
    %% the nickname in the form "user[number]" manually such that a new client happens
    %% to generate the same random number as you assigned to your client.
    whereis(server)!{self(), connect, InitialState#cl_st.nick},
    %% if running test suite, tell test suite that client is up
    case whereis(testsuite) of
	undefined -> ok;
	TestSuitePID -> TestSuitePID!{client_up, self()}
    end,
    %% Begins listening
    listen(InitialState).

%% This method handles all incoming messages from either the GUI or the
%% chatrooms that are not directly tied to an ongoing request cycle.
listen(State) ->
    receive
        {request, From, Ref, Request} ->
	    %% the loop method will return a response as well as an updated
	    %% state to pass along to the next cycle
            {Response, NextState} = loop(State, Request, Ref),
	    case Response of
		{dummy_target, Resp} ->
		    io:format("Use this for whatever you would like~n"),
		    From!{result, self(), Ref, {dummy_target, Resp}},
		    listen(NextState);
		%% if shutdown is received, terminate
		shutdown ->
		    ok_shutdown;
		%% if ok_msg_received, then we don't need to reply to sender.
		ok_msg_received ->
		    listen(NextState);
		%% otherwise, reply to sender with response
		_ ->
		    From!{result, self(), Ref, Response},
		    listen(NextState)
	    end
    end.

%% This function just initializes the default state of a client.
%% This should only be used by the GUI. Do not change it, as the
%% GUI code we provide depends on it.
initial_state(Nick, GUIName) ->
    #cl_st { gui = GUIName, nick = Nick, con_ch = maps:new() }.

%% ------------------------------------------
%% loop handles each kind of request from GUI
%% ------------------------------------------
loop(State, Request, Ref) ->
    case Request of
	%% GUI requests to join a chatroom with name ChatName
	{join, ChatName} ->
	    do_join(State, Ref, ChatName);

	%% GUI requests to leave a chatroom with name ChatName
	{leave, ChatName} ->
	    do_leave(State, Ref, ChatName);

	%% GUI requests to send an outgoing message Message to chatroom ChatName
	{outgoing_msg, ChatName, Message} ->
	    do_msg_send(State, Ref, ChatName, Message);

	%% GUI requests the nickname of client
  % Assignment Spec Part 3.4: "/whoami"
	whoami ->
      % Retrieve current nickname
      Nickname = State#cl_st.nick,
      % Create the response
      Response = {result, self(), Ref, Nickname},
      % Send the response to the GUI
      whereis(list_to_atom(State#cl_st.gui))!Response,
      % Return {Response, NextState} to the "listen" function
      {Response, State};
	    % {{dummy_target, dummy_response}, State};

	%% GUI requests to update nickname to Nick
	{nick, Nick} ->
            do_new_nick(State, Ref, Nick);

	%% GUI requesting to quit completely
	quit ->
	    do_quit(State, Ref);

	%% Chatroom with name ChatName has sent an incoming message Message
	%% from sender with nickname SenderNick
	{incoming_msg, SenderNick, ChatName, Message} ->
	    do_new_incoming_msg(State, Ref, SenderNick, ChatName, Message);

	{get_state} ->
	    {{get_state, State}, State};

	%% Somehow reached a state where we have an unhandled request.
	%% Without bugs, this should never be reached.
	_ ->
	    io:format("Client: Unhandled Request: ~w~n", [Request]),
	    {unhandled_request, State}
    end.


% NOTE NOTE NOTE NOTE NOTE NOTE NOTE NOTE NOTE NOTE NOTE NOTE NOTE
% YOU MUST FOLLOW ALL OF THE SPECIFICATIONS STARTING ON PAGE 11 EXTREMELY CLOSELY
% SO YOU DON'T FAIL THE TEST CASES!!!
% END NOTE END NOTE END NOTE END NOTE END NOTE END NOTE END NOTE

%% executes `/join` protocol from client perspective
% If such a chatroom doesn't exist, the server must create one.
% Otherwise, join the chatroom and have the server tell the chatroom that the client wants to join it
% and update the list of chatroom members after joining.
% The chatroom has to tell the client about it, whether it was just created or
% already exists, once the client joins.

% If the client is in the specified chatroom, send an error message.
% Else, continue.
% Client asks to join the specified chatroom, so it requests to do so from the server.
% Once the server gets the request, it checks if the chatroom exists. If it
% doesn't already exist, the server needs to spawn the chatroom.
% Then the server looks up the requesting client nickname from its state record (serv_st)
% Once the chatroom is either created or found, the server needs to tell the chatroom that
% the requesting client is joining.
% Server updates its own record for chatroom registrations to include the new change with the requesting client.
% Actually, for the rest, just refer to the "/join" section of the assignment spec, pages 6 and 7.

% WHAT THE CLIENT HAS TO DO IN THE LIST OF STEPS:
% The client has to do steps 2, 3, half of step 8, and 9
do_join(State, Ref, ChatName) ->
    % Step 2 in do_join
    % I think you should check con_ch and return an error if the map doesn't
    % contain the requested chatroom name.
    % This will be false if the chatroom hasn't yet been joined. Else it will be true
    % {{result, self(), Ref, err}, State}.
    % {result, self(), Ref, err}.
    Chatroom_Joined = maps:is_key(ChatName,State#cl_st.con_ch),
    if
      % /join Step 2
      Chatroom_Joined == true -> % If we're already in the chatroom
        % io:format("in the chatroom already~n"),
        % Return the following tuple which will be sent to the GUI by the "loop" function
        % {{result, self(), Ref, err}, State};

        % Because we haven't updated the state in this error, we bind UpdatedState to State
        UpdatedState = State,

        % Because we reached an error and have joined this chatroom already,
        % the final map of connected channels will remain the same as it was.
        % FinalConnectedChannels = State#cl_st.con_ch,

        % Create response to send to the GUI and "listen" function
        Response = {result, self(), Ref, err};

        % The following statement was moved out of the "if" block since it's duplicate
        % code.
        % % Send the error response data to the GUI. Note that this is the issue with
        % % my code from 11/22, where the GUI's "lists:foreach" function in the
        % % do_join function for the GUI was crashing. To see what I'm talking about,
        % % uncomment this line. This was what the TAs suggested after looking at
        % % my code and the errors I got. We have to convert this from a string
        % % to an atom using the "list_to_atom" command to satisfy the input requirements
        % % for the "whereis" function.
        % whereis(list_to_atom(State#cl_st.gui))!Response;

        % send an error to the gui, broken, look above for correct one
        % State#cl_st.gui!{result, self(), Ref, err};

      % /join Step 3
      Chatroom_Joined == false -> % we're not in the chatroom
        % io:format("Proceed, we aren't in the chatroom"),
        % Send the tuple message requested in step 3 to the server, wherever it may be
        % (or, more literally, what PID is associated with the registered name "server")
        whereis(server)!{self(), Ref, join, ChatName},

        % Debugging message for locating placement
        % io:format("Tried sending to server.~n"),

        % /join Step 8 (second half of it)
        % Await receiving this message from the Chatroom Process
        % with the chatroom's PID, Reference ID for this sequence, the atom "connect",
        % and the chat history.
        receive
          % Upon receving the message
          {ChatroomPID, Ref, connect, History} ->
              % Print message to console (used during debugging)
              % Debugging message for locating placement
              % io:format("Client received response from server just now. Beginning Step 9...~n"),
              % /join Step 9

              % NOTE: This was implemented even better in chatroom.erl
              % % (This next block of lines is not in the assignment
              % % spec, I've just noticed this in various chat mediums
              % % and thought I should include it in this one too. The assignment
              % % spec stuff resumes after NewHistory is created.)
              % Auto_Generated_I_Joined_Message = "\nAUTOMATICALLY GENERATED: I joined this chatroom.\n",
              % % Update the received history to include the new message that we will send
              % % to the chatroom automatically saying that we joined the chatroom.
              % NewHistory = History ++ [{State#cl_st.nick, Auto_Generated_I_Joined_Message}],
              % % NewHistory = History ++ [{State#cl_st.nick, "\nAUTOMATICALLY GENERATED: I joined this chatroom.\n"}],

              % Update the client's map containing the registered chatrooms
              FinalConnectedChannels = maps:put(ChatName, ChatroomPID, State#cl_st.con_ch),

              % Create the Updated State for the client
              UpdatedState = #cl_st{gui = State#cl_st.gui, nick = State#cl_st.nick, con_ch = FinalConnectedChannels},

              % NOTE: This was implemented even better in chatroom.erl
              % % Send the automated message about joining ChatName to the chatroom
              % % with the name ChatName. For the state, use UpdatedState instead
              % % of State, as UpdatedState has the new list
              % % of chatrooms (i.e. Connected Channels (i.e. UpdatedState#cl_st.con_ch)).
              % do_msg_send(UpdatedState, Ref, ChatName, Auto_Generated_I_Joined_Message),
              % % do_msg_send(UpdatedState, Ref, ChatName, "\nAUTOMATICALLY GENERATED: I joined this chatroom.\n"),

              % OLD: Update the client's map containing the registered chatrooms
              % by adding the new chatroom to the map with the key being
              % the name of the chatroom and the corresponding value being
              % the chatroom with the name ChatName (in STRING FORM) to
              % Connected_Channels_Singleton_Map = maps:from_list([{ChatName, ChatroomPID}]),
              % maps:put(ChatName, ChatroomPID, State#cl_st.con_ch),
              % Complete the addition to the map by merging the new entry to the old map
              % FinalConnectedChannels = maps:merge(State#cl_st.con_ch, Connected_Channels_Singleton_Map),

              % Debugging message for locating placement
              % io:format("Put it in the maps~n"),
              % map_list_printer(maps:to_list(FinalConnectedChannels)),
              % Return the result, Reference ID, and History to the GUI,
              % since it will be sent via the "loop" function, and then also supply
              % the new Client State.
              % io:format("Sent message back?")

              % Create response to send to the GUI and "listen" function
              % Response = {result, self(), Ref, NewHistory},
              Response = {result, self(), Ref, History}

              % Determining if State#cl_st.gui is the GUI's PID number or its registered
              % name to determine how to properly send data to it. It was determined
              % to be a name in string form.
              % io:format("\nValue associated with State#cl_st.gui: "),
              % io:format(State#cl_st.gui),
              % io:format("\n\n")

              % % Send the response data to the GUI. Note that this is the issue with
              % % my code from 11/22, where the GUI's "lists:foreach" function in the
              % % do_join function for the GUI was crashing. To see what I'm talking about,
              % % uncomment this line. This was what the TAs suggested after looking at
              % % my code and the errors I got. We have to convert this from a string
              % % to an atom using the "list_to_atom" command to satisfy the input requirements
              % % for the "whereis" function.
              % whereis(list_to_atom(State#cl_st.gui))!Response


              % {{result, self(), Ref, History}, #cl_st{gui = State#cl_st.gui, nick = State#cl_st.nick, con_ch = FinalConnectedChannels}}
              % State#cl_st.gui!{result, self(), Ref, History}
        end
    end,
    % end.

    % Send the response data to the GUI. Note that this is the issue with
    % my code from 11/22, where the GUI's "lists:foreach" function in the
    % do_join function for the GUI was crashing. To see what I'm talking about,
    % uncomment this line. This was what the TAs suggested after looking at
    % my code and the errors I got. We have to convert this from a string
    % to an atom using the "list_to_atom" command to satisfy the input requirements
    % for the "whereis" function.
    whereis(list_to_atom(State#cl_st.gui))!Response,

    % UpdatedState = #cl_st{gui = State#cl_st.gui, nick = State#cl_st.nick, con_ch = FinalConnectedChannels},
    % The following commented-out line seems to make everything but the GUI work properly.
    % {{dummy_target, dummy_response}, UpdatedState}.
    {Response, UpdatedState}.
    % io:format("client:do_join(...): IMPLEMENT ME~n"),

    % {{dummy_target, dummy_response}, State}.

% This never worked, so disregard it.
% Debugging function to print the contents of a list that was converted from a map
% map_list_printer(My_List) ->
%   list_printer_helper(My_List, 0).
%
% % Brains of map_list_printer
% list_printer_helper(My_List, Counter) ->
%   case My_List of
%     [] ->
%       io:format("~nlist has no more elements.~nList length: ~d~n", Counter);
%     [List_Head | Rest_Of_List] ->
%       % io:format("Element ~d in My_List: ~p~n", Counter, tuple_to_list(List_Head)),
%       io:format("~s~n",lists:nth(1,tuple_to_list(List_Head))),%,lists:nth(1,tuple_to_list(List_Head))),
%       New_Counter = Counter + 1,
%       list_printer_helper(Rest_Of_List, New_Counter)
%   end.

%% executes `/leave` protocol from client perspective
% Description of "/leave" on pages 7 and 8

% WHAT THE CLIENT HAS TO DO IN THE LIST OF STEPS:
% The client has to do steps 2, 3, part of 7, 8, and 9
do_leave(State, Ref, ChatName) ->
    % Create a variable for the GUI's PID so you don't have to keep retyping that line.
    GUI_PID = whereis(list_to_atom(State#cl_st.gui)),
    % Is the client in the list of chatrooms that you're connected to?
    Connected_To_Chatroom = maps:is_key(ChatName, State#cl_st.con_ch),
    if
      % /leave Step 2
      % If we're not connected to the chatroom we want to leave
      Connected_To_Chatroom == false ->
        % Create the updated list of connected chatrooms to be the same as before,
        % since we didn't actually change the variable.
        FinalConnectedChannels = State#cl_st.con_ch,
        % Create the error response
        Response = {result, self(), Ref, err};
        % Send the error message to the GUI.
        % GUI_PID!Response;
      % /leave Step 3
      % If we are already connected to the chatroom
      Connected_To_Chatroom == true ->
        % io:format("I can sense a connection now.\n"),
        whereis(server)!{self(), Ref, leave, ChatName},
        % /leave Step 7
        % Wait to receive the ack_leave message from the server
        receive
          % Upon receving the message from the server
          % The _Server_PID variable is unused, so the "_" goes before it
          {_Server_PID, Ref, ack_leave} ->
            % /leave Step 8
            % Update connected channels (chatrooms) map by removing
            % the chatroom with the name ChatName from the connected chatrooms
            FinalConnectedChannels = maps:remove(ChatName, State#cl_st.con_ch),
            % Create the Response
            Response = {result, self(), Ref, ok}
            % io:format("Connection closed.\n")
        end % End the receive block
    end,

    % /leave Step 2 or 9
    % Send the GUI the response
    GUI_PID!Response,
    % Create the Updated State
    UpdatedState = #cl_st{gui = State#cl_st.gui, nick = State#cl_st.nick, con_ch = FinalConnectedChannels},
    % Return the response and updated state.
    {Response, UpdatedState}.
    % io:format("client:do_leave(...): IMPLEMENT ME~n"),
    % {{dummy_target, dummy_response}, State}.

%% executes `/nick` protocol from client perspective
% Description of "/nick new_nickname" on page 8
% NOTE: The new nickname MUST start with a LOWERCASE letter.

% WHAT THE CLIENT HAS TO DO IN THE LIST OF STEPS:
% The client has to do steps 2, 3, part of 4 (maybe), part of 7, and 8.
do_new_nick(State, Ref, NewNick) ->
    % Create a variable for the GUI's PID so you don't have to keep retyping that line.
    GUI_PID = whereis(list_to_atom(State#cl_st.gui)),
    Current_Nickname = State#cl_st.nick,
    if
      % /nick Step 2
      NewNick == Current_Nickname ->
        Response = {result, self(), Ref, err_same};
      % /nick Step 3
      NewNick =/= Current_Nickname ->
        whereis(server)!{self(), Ref, nick, NewNick},
        % /nick Step 4 or 7
        receive
          % /nick Step 4
          % Upon receving an error message from the server
          % The _Server_PID variable is unused, so the "_" goes before it
          {_Server_PID, Ref, err_nick_used} ->
            % Make the response an error that the nickname is in use by another client
            Response = {result, self(), Ref, err_nick_used};
          % /nick Step 7
          % Upon receving the success message from the server
          % The _Server_PID variable is unused, so the "_" goes before it
          {_Server_PID, Ref, ok_nick} ->
            % Create the Response
            Response = {result, self(), Ref, ok_nick}
        end % End the receive statement
    end,
    % /nick Step 2, 4, or 8
    GUI_PID!Response,
    % Create the updated state with the new nickname. The reason that I didn't do it inside
    % the "if" block is that the error step, Step 2, says that the current nickname is the
    % same as the new nickname, so creating a state where nick = Current_Nickname is identical
    % to nick = NewNick, since Current_Nickname == NewNick.
    UpdatedState = #cl_st{gui = State#cl_st.gui, nick = NewNick, con_ch = State#cl_st.con_ch},
    % Return the response and updated state.
    {Response, UpdatedState}.
    % io:format("client:do_new_nick(...): IMPLEMENT ME~n"),
    % {{dummy_target, dummy_response}, State}.

%% executes send message protocol from client perspective
% Description of "Send a Message->Sending client" on page 9

% WHAT THE CLIENT HAS TO DO IN THE LIST OF STEPS:
% Sending client steps (i.e. this function)
% The sending client has to do steps 2, 3, part of 4, and 5
% NOTE NOTE NOTE NOTE NOTE: Make the initial joining automated message in the chatroom's
% do_register function send from the do_join client function rather from
% the internal chatroom process so it's properly populated in the chat.
do_msg_send(State, Ref, ChatName, Message) ->
    % Sending client Step 2
    Chatroom_PID = maps:get(ChatName, State#cl_st.con_ch),
    % Sending client Step 3
    Chatroom_PID!{self(), Ref, message, Message},
    % Sending client Step 4
    receive
      % The _Received_PID_From_Chatroom variable is unused, so the "_" goes before it
      {_Received_PID_From_Chatroom, Ref, ack_msg} ->
        % Create a variable for the GUI's PID so you don't have
        % to keep retyping that line.
        GUI_PID = whereis(list_to_atom(State#cl_st.gui)),
        % Sending client Step 5
        Response = {result, self(), Ref, {msg_sent, State#cl_st.nick}},
        GUI_PID!Response
    end,
    {Response, State}.
    % io:format("client:do_msg_send(...): IMPLEMENT ME~n"),
    % {{dummy_target, dummy_response}, State}.

%% executes new incoming message protocol from client perspective
% Description of "Send a Message->Receiving client(s)" on pages 9 and 10

% WHAT THE CLIENT HAS TO DO IN THE LIST OF STEPS:
% Receiving client steps (i.e. this function)
% 3, and the explanation for the code below is in the assignment spec on page 10.
% This is already given by default.
do_new_incoming_msg(State, _Ref, CliNick, ChatName, Msg) ->
    %% pass message along to gui
    gen_server:call(list_to_atom(State#cl_st.gui), {msg_to_GUI, ChatName, CliNick, Msg}),
    {ok_msg_received, State}.

%% executes quit protocol from client perspective
% Description of "/quit" on pages 10 and 11

% NOTE FROM ASSIGNMENT SPEC: if the GUI window does not close, BUT when you enter commands into the prompt and hit
% enter, nothing happens, do not worry. There is some issue we were having with the visual element of the
% GUI properly exiting, and it was frankly not worth our time to debug this as it does not affect the students’
% end of the assignment. If someone comes up with a fix, that’s great and please let us know, but it is not
% your responsibility to fix this.

% WHAT THE CLIENT HAS TO DO IN THE LIST OF STEPS:
% The client has to do steps 2, part of 4, 5, and 6.
do_quit(State, Ref) ->
    % /quit Step 2
    whereis(server)!{self(), Ref, quit},
    % /quit Step 4
    receive
      % The _Server_PID variable is unused, so the "_" goes before it
      {_Server_PID, Ref, ack_quit} ->
        % /quit Step 5
        % Send the quit message to the GUI
        whereis(list_to_atom(State#cl_st.gui))!{self(), Ref, ack_quit}
    end,
    % /quit Step 6
    % OLD, DID NOT WORK ENTIRELY.
    % "Stop" is a function that stops the process with the given PID.
    % In our case, we're using stop(self()) to
    % stop the process that our own self is running.
    % Giving "stop" one argument means that it will exit normally,
    % which is the main caveat of /quit Step 6.
    % proc_lib:stop(self()).

    % Terminate the process normally.
    exit(normal).
    % io:format("client:do_quit(...): IMPLEMENT ME~n"),
    % {{dummy_target, dummy_response}, State}.

% NOTE NOTE NOTE NOTE NOTE NOTE NOTE NOTE NOTE NOTE NOTE NOTE NOTE
% YOU MUST FOLLOW ALL OF THE SPECIFICATIONS STARTING ON PAGE 11 EXTREMELY CLOSELY
% SO YOU DON'T FAIL THE TEST CASES!!!
% END NOTE END NOTE END NOTE END NOTE END NOTE END NOTE END NOTE
